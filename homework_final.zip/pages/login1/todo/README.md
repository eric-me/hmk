# To Do List App

Simple to do list app built using local storage to persist data.

Live Demo: http://daniyalaamir.github.io/to-do-list-app/

![to-do-list-app] (https://cloud.githubusercontent.com/assets/11576208/10151031/83e0a63c-6611-11e5-9da9-20a2ef994b81.jpg)
