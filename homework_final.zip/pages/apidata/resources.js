$(document).ready(function () {

 $('#retrieve-resources').click(function () {
 var displayResources = $('#display-resources');

 displayResources.text('Loading data from JSON source...');

 $.ajax({
 type: "GET",
 url: "hkhospital.json",
 success: function(result)
 {
 console.log(result);
 var output="<table><thead><tr><th>Cluster</th><th>Hospital</th><th>Address</th></thead><tbody>";
 for (var i in result)
 {
 output+="<tr><td>" + result[i].cluster_eng + "</td><td>" + result[i].institution_eng + "</td><td>" + result[i].address_eng + "</td></tr>";
 }
 output+="</tbody></table>";

 displayResources.html(output);
 $("table").addClass("table");
 }
 });

 });
});