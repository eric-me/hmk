# Ajax-Live-Search-using-AngularJs
Ajax Live Search using custom filter Angular JS 

### See Tutorial here  - 
http://code.ciphertrick.com/2015/02/07/live-search-using-custom-filter-in-angular-js/

### Demo - 
http://code.ciphertrick.com/demo/angularajaxsearch/
