Structure
index.html
    Pages
      fact1.html
      fact2.html
      fact3.html
      fact4.html
      footer.html
      index.html
      search.html
      uinfo.html
      login1
         login
            login.view.html
         register
            register.view.html
         home
            home.view.html
         
      
References
Portal Template

Login Template
http://jasonwatmore.com/post/2015/03/10/angularjs-user-registration-and-login-example-tutorial
Aids Drugs API

To do list Template

Search
https://ciphertrick.com/demo/angularajaxsearch/


8 Mistakes That Can Affect Your HIV Treatment
https://www.everydayhealth.com/hs/hiv-health/mistakes-that-affect-hiv-treatment-pictures/#01